//Permet de définir le type contenu dans la pile, pour ce programme. A voir si c'est utile de le garder ou non
#undef TYPEPILE
#define TYPEPILE TCarte


//Fonctions


//Programme Principal
int main(){
    return 0;
}


//Définition des Fonctions

